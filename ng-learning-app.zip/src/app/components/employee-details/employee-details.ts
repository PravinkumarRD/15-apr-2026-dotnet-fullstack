import { Component, Input, EventEmitter, Output } from '@angular/core';

import { Employee } from "../../models/employee";

@Component({
  selector: 'bajaj-employee-details',
  imports: [],
  templateUrl: './employee-details.html',
  styleUrl: './employee-details.css',
})
export class EmployeeDetails {
  title: string = "Profile Of - ";
  @Input() employee: Employee;
  @Output() sendMessage: EventEmitter<string> = new EventEmitter<string>();

  fireSendMessageEvent():void{
    this.sendMessage.emit("Selected Employee is processed and transfered to Mumbai!");
  }

}
