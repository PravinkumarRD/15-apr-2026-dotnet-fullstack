import { Component } from '@angular/core';

import { Employee } from "../../models/employee";
import { EmployeeDetails } from "../employee-details/employee-details";

@Component({
  selector: 'bajaj-employees-list',
  imports: [EmployeeDetails],
  templateUrl: './employees-list.html',
  styleUrl: './employees-list.css',
})
export class EmployeesList {
  title: string = "Welcome To Bajaj Employees List!";
  subTitle: string = "Core Developement Members of Bajaj!";
  employees: Employee[] = [
    {
      employeeId: 2370,
      employeeName: "Pravinkumar R. D.",
      address: "Suncity, A8/404",
      city: "Pune",
      zipcode: 411051,
      phone: "+91 23892893",
      email: "pravin.r.d@bonaventures.com",
      skillSets: "Microsoft/JavaScript",
      country: "India",
      joiningDate: new Date(),
      avatar: "images/noimage.png"
    },
    {
      employeeId: 2372,
      employeeName: "Manish Kaushik",
      address: "Mooncity, Z8/404",
      city: "Raipur",
      zipcode: 459899,
      phone: "+91 9039039090",
      email: "manish.kaushik@bonaventures.com",
      skillSets: "DBA",
      country: "India",
      joiningDate: new Date(),
      avatar: "images/noimage.png"
    },
    {
      employeeId: 2374,
      employeeName: "Alisha C.",
      address: "Mooncity, B8/404",
      city: "Mumbai",
      zipcode: 510512,
      phone: "+91 30003000",
      email: "alisha.c@bonaventures.com",
      skillSets: "Java",
      country: "India",
      joiningDate: new Date(),
      avatar: "images/noimage.png"
    },
    {
      employeeId: 2376,
      employeeName: "Mahesh Panhale",
      address: "Hira Nandani City",
      city: "Mumbai",
      zipcode: 334554,
      phone: "+91 342323233",
      email: "mahesh.p@bonaventures.com",
      skillSets: "Develper/CEO",
      country: "India",
      joiningDate: new Date(),
      avatar: "images/noimage.png"
    }
  ];
  childMessage:string;
  selectedEmployee: Employee;
  onEmployeeSelection(employee: Employee): void {
    this.selectedEmployee = employee;
  }
  onChildComponentMessage(message: string): void {
    this.childMessage = message;
  }
}
