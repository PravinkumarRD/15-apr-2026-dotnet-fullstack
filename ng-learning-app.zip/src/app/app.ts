import { Component } from '@angular/core';
import { EmployeesList } from './components/employees-list/employees-list';
import { EventsList } from "./components/events-list/events-list";

@Component({
  selector: 'app-root',
  //template:'<h1>Welcome To Angular RnD App!</h1><hr/><h6>For Testing Purposes only!</h6>',
  // template:`
  //   <h1>Welcome To Angular RnD App!</h1>
  //   <hr/>
  //   <h6>For Testing Purposes only!</h6>
  // `,
  templateUrl: './app.html',
  styleUrl: './app.css',
  imports: [EmployeesList, EventsList]
})
export class App {
  title: string = "Welcome To Angular RnD App Of Bajaj!";
  subTitle: string = "For Testing Purposes only!";
  isActive: boolean = false;
  contents: string = "Hello There! <script>alert('You have been hacked!')</script> Welcome To Bajaj!";
  changeTitle():void{
    this.title="Welcome To Angular RnD App Of Bajaj! Bangalore!";;
  }
}
