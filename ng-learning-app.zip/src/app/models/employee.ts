export class Employee {
    employeeId: number;
    employeeName: string;
    address: string;
    city: string;
    phone: string;
    email: string;
    country: string;
    skillSets: string;
    avatar: string;
    joiningDate: Date;
    zipcode: number;
}
